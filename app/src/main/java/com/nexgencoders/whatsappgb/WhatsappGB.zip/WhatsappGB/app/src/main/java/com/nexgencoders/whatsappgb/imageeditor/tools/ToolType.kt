package com.nexgencoders.whatsappgb.imageeditor.tools
enum class ToolType {
    SHAPE, TEXT, ERASER, FILTER, EMOJI, STICKER
}