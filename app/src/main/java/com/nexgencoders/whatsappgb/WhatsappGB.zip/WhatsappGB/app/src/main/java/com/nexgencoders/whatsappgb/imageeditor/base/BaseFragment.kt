package com.nexgencoders.whatsappgb.imageeditor.base

import androidx.fragment.app.Fragment

abstract class BaseFragment(layoutId: Int) : Fragment(layoutId)