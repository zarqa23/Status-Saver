package com.nexgencoders.whatsappgb.ui.activity

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.os.CountDownTimer
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.RequestConfiguration
import com.nexgencoders.whatsappgb.MyApplication
import com.nexgencoders.whatsappgb.databinding.ActivitySplashBinding
import com.nexgencoders.whatsappgb.utils.GoogleMobileAdsConsentManager
import com.nexgencoders.whatsappgb.utils.startActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

@SuppressLint("CustomSplashScreen")
class SplashActivity : AppCompatActivity() {
    private lateinit var binding: ActivitySplashBinding

    private lateinit var googleMobileAdsConsentManager: GoogleMobileAdsConsentManager
    private val isMobileAdsInitializeCalled = AtomicBoolean(false)
    private val gatherConsentFinished = AtomicBoolean(false)
    private var secondsRemaining: Long = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySplashBinding.inflate(layoutInflater)
        setContentView(binding.root)
        handleClicks()
    }

    private fun handleClicks() {
        binding.btnStart.setOnClickListener {
            createTimer()
            googleMobileAdsConsentManager = GoogleMobileAdsConsentManager.getInstance(applicationContext)
            googleMobileAdsConsentManager.gatherConsent(this) { consentError ->
                if (consentError != null) {
                    Log.w(LOG_TAG, String.format("%s: %s", consentError.errorCode, consentError.message))
                }

                gatherConsentFinished.set(true)

                if (googleMobileAdsConsentManager.canRequestAds) {
                    initializeMobileAdsSdk()
                }

                if (secondsRemaining <= 0) {
                    startMainActivity()
                }
            }

            if (googleMobileAdsConsentManager.canRequestAds) {
                initializeMobileAdsSdk()
            }
        }
    }

    private fun createTimer() {
        val countDownTimer: CountDownTimer =
            object : CountDownTimer(COUNTER_TIME_MILLISECONDS, 1000) {
                override fun onTick(millisUntilFinished: Long) {
                    secondsRemaining = TimeUnit.MILLISECONDS.toSeconds(millisUntilFinished) + 1
                }

                override fun onFinish() {
                    secondsRemaining = 0
                    (application as MyApplication).showAdIfAvailable(
                        this@SplashActivity,
                        object : MyApplication.OnShowAdCompleteListener {
                            override fun onShowAdComplete() {
                                if (gatherConsentFinished.get()) {
                                    startMainActivity()
                                }
                            }
                        },
                    )
                }
            }
        countDownTimer.start()
    }

    private fun initializeMobileAdsSdk() {
        if (isMobileAdsInitializeCalled.getAndSet(true)) {
            return
        }
        MobileAds.setRequestConfiguration(
            RequestConfiguration.Builder()
                .setTestDeviceIds(listOf(MyApplication.TEST_DEVICE_HASHED_ID))
                .build()
        )

        CoroutineScope(Dispatchers.IO).launch {
            MobileAds.initialize(this@SplashActivity) {}
            runOnUiThread {
                (application as MyApplication).loadAd(this@SplashActivity)
            }
        }
    }

    fun startMainActivity() {
        startActivity(HomeActivity::class.java)
    }

    companion object {
        private const val COUNTER_TIME_MILLISECONDS = 2000L
        private const val LOG_TAG = "SplashActivity"
    }
}