package com.nexgencoders.whatsappgb.ui.fragment

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.nexgencoders.whatsappgb.R
import com.nexgencoders.whatsappgb.databinding.FragmentSearchMessageBinding
import com.nexgencoders.whatsappgb.utils.Common.getAllWhatsappBusinessNumbers
import com.nexgencoders.whatsappgb.utils.Common.getAllWhatsappNumbers
import com.nexgencoders.whatsappgb.utils.Common.isNumberInList
import com.nexgencoders.whatsappgb.utils.HomeConst.isWhatsAppBusinessInstalled
import com.nexgencoders.whatsappgb.utils.HomeConst.isWhatsAppInstalled
import com.nexgencoders.whatsappgb.utils.loadSmallMediumSizeNativeAds
import com.nexgencoders.whatsappgb.utils.toast
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext


class SearchMessageFragment : Fragment() {

    private var _binding: FragmentSearchMessageBinding? = null
    private val binding get() = _binding!!
    private var isWhatsapp: Boolean = false

    private val requestPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted: Boolean ->
            if (isGranted) {
                searchNumber(isWhatsapp)
            } else {
                context?.toast("Contact permission is required to access contacts")
            }
        }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSearchMessageBinding.inflate(layoutInflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        loadSmallMediumSizeNativeAds(requireContext(), R.string.small_medium_native_ads,binding.templateView)
        binding.btnWhatsApp.setOnClickListener {
            isWhatsapp = true
            if (isContactPermissionGranted()) {
                searchNumber(isWhatsapp)
            } else {
                requestContactPermission(isWhatsapp)
            }

        }

        binding.btnBusWa.setOnClickListener {
            isWhatsapp = false
            if (isContactPermissionGranted()) {
                searchNumber(isWhatsapp)
            } else {
                requestContactPermission(isWhatsapp)
            }

        }

        binding.btnBack.setOnClickListener {
            findNavController().navigateUp()
        }

    }

    private fun isContactPermissionGranted(): Boolean {
        return ContextCompat.checkSelfPermission(
            requireContext(),
            Manifest.permission.READ_CONTACTS
        ) == PackageManager.PERMISSION_GRANTED
    }

    private fun requestContactPermission(isWhatsApp: Boolean) {
        if (isContactPermissionGranted()) {
            searchNumber(isWhatsApp)
        } else {
            requestPermissionLauncher.launch(Manifest.permission.READ_CONTACTS)
        }
    }

    private fun searchNumber(isWhatsApp: Boolean) {
        val countryCode = binding.ccp.selectedCountryCodeWithPlus
        val phoneNumber = binding.numberInput.text.toString().trim()
        if (phoneNumber.isEmpty()) {
            context?.toast("Please enter a phone number")
            return
        }

        val fullPhoneNumber = countryCode + phoneNumber
        if (isWhatsApp) {
            if (isWhatsAppInstalled(requireContext())) {
                lifecycleScope.launch(Dispatchers.IO) {
                    val whatsappNumbers = getAllWhatsappNumbers(requireContext().contentResolver)
                    val whatsappBusinessNumbers =
                        getAllWhatsappBusinessNumbers(requireContext().contentResolver)
                    withContext(Dispatchers.Main) {
                        Log.d("log1", "WhatsApp Contacts: $whatsappNumbers")
                        if (isNumberInList(fullPhoneNumber, whatsappNumbers)) {
                            context?.toast("found")
                        } else {
                            context?.toast("not found")
                        }
                    }
                }
            } else {
                context?.toast("WhatsApp Not Installed")
            }
        } else {
            if (isWhatsAppBusinessInstalled(requireContext())) {
                lifecycleScope.launch(Dispatchers.IO) {
                    val whatsappBusinessNumbers =
                        getAllWhatsappBusinessNumbers(requireContext().contentResolver)
                    withContext(Dispatchers.Main) {
                        if (isNumberInList(fullPhoneNumber, whatsappBusinessNumbers)) {
                            context?.toast("found")
                        } else {
                            context?.toast("not found")
                        }
                    }
                }
            } else {
                context?.toast("WhatsApp Business Not Installed")
            }
        }

    }


    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }
}