package com.nexgencoders.whatsappgb.model

data class CaptionDataModel (var icon:Int, var title:String)