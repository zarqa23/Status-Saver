package com.nexgencoders.mylibrary.shape

enum class ArrowPointerLocation { START, END, BOTH }