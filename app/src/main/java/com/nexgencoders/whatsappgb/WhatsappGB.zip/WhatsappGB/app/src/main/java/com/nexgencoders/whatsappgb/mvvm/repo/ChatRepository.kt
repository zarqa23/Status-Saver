package com.nexgencoders.whatsappgb.mvvm.repo

import androidx.lifecycle.LiveData
import com.nexgencoders.whatsappgb.database.DatabaseRepository
import com.nexgencoders.whatsappgb.model.Chat
import com.nexgencoders.whatsappgb.model.DeletedMessage
import com.nexgencoders.whatsappgb.utility.isValidTitle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import javax.inject.Singleton

@Singleton
class ChatRepository {
    private val database: DatabaseRepository = DatabaseRepository
    suspend fun saveMessage(chat: Chat) {
        withContext(Dispatchers.IO) {
            if (chat.message.isValidTitle()) {
                val lastMessage = database.database.userDao().getLastMessage(chat.user)
                if (lastMessage != null) {
                    if (chat.message != lastMessage.message && chat.time != lastMessage.time) database.database.userDao().save(chat)
                } else {
                    database.database.userDao().save(chat)
                }
            }
        }
    }

    suspend fun fetchChats(): LiveData<List<Chat>> {
        return withContext(Dispatchers.IO) {
            database.database.userDao().getChats()
        }
    }

    suspend fun fetchMessagesByUser(user: String,app: String): LiveData<List<Chat>> {
        return withContext(Dispatchers.IO) {
            database.database.userDao().getMessagesByUser(user,app)
        }
    }

    suspend fun lastMessage(user: String): DeletedMessage? {
        return withContext(Dispatchers.IO) {
            database.database.userDao().getLastMessage(user)
        }
    }

    suspend fun messageIsDeleted(id: String) {
        withContext(Dispatchers.IO) {
            database.database.userDao().messageIsDeleted(id)
        }
    }
}