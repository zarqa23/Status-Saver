package com.nexgencoders.whatsappgb.model

data class CaptionData(val id: Int,
                       val text: String)
