package com.nexgencoders.mylibrary

class TextBorder(
    var corner: Float,
    var backGroundColor: Int,
    var strokeWidth: Int,
    var strokeColor: Int
)