package com.nexgencoders.whatsappgb.analyzer

interface ScanningResultListener {
    fun onScanned(result: String)
}