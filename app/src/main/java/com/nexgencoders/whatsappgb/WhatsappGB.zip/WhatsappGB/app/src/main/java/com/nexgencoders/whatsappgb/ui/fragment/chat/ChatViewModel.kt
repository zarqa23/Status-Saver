package com.nexgencoders.whatsappgb.ui.fragment.chat

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.liveData
import com.nexgencoders.whatsappgb.model.Chat
import com.nexgencoders.whatsappgb.mvvm.repo.ChatRepository

class ChatViewModel: ViewModel() {
    private val repository: ChatRepository = ChatRepository()

    val getChatList: LiveData<List<Chat>> = liveData {
        val response = repository.fetchChats()
        emitSource(response)
    }

    fun  getChatByUser(user: String,app: String): LiveData<List<Chat>> = liveData {
        val response = repository.fetchMessagesByUser(user,app)
        emitSource(response)
    }
}