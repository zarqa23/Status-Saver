package com.nexgencoders.whatsappgb.model

data class HomeDataModel (var icon:Int,var title:String,var ref:String)